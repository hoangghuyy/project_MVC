﻿using project_mvc.Services.Admin.Models;

namespace project_mvc.Areas.Admin.ViewModels
{
	public class UserAdminViewModel
	{
		public List<UserAdminItem>? ListItems { get; set; }
		public UserAdmins? Item { get; set; }

	}
}
