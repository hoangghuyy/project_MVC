﻿using Microsoft.AspNetCore.Mvc;
using project_mvc.Areas.Admin.ViewModels;
using project_mvc.Helpers;
using project_mvc.Services.Admin;
using project_mvc.Services.Admin.Models;

namespace project_mvc.Areas.Admin.Controllers
{
    public class UserController : BaseController
    {
		private readonly UserDa UserDa;
		private readonly BaseDa BaseDa;

		public UserController()
		{
			UserDa = new UserDa(WebConfig.ConnectionString!);
			BaseDa = new BaseDa(WebConfig.ConnectionString!);

		}
		private readonly JsonMessage msg = new()
		{
			Errors = true,
			Message = "Không có hành động nào được thực hiện."
		};
		public IActionResult Index()
        {
            return View();
        }

		[Obsolete]
		public async Task<IActionResult> ListItems()
		{
			SearchModel search = new();
			await TryUpdateModelAsync(search);
			int pageSize = 20;
			UserAdminViewModel model = new()
			{
				ListItems = await UserDa.ListSearch(search, search.Page, pageSize)
			};
			int total = model.ListItems != null && model.ListItems.Count != 0 ? model.ListItems.FirstOrDefault()!.TotalRecords : 0;
			ViewBag.Pagging = GetPage(search.Page, total, pageSize);
			return View(model);
		}

		public IActionResult AjaxFormAdd()
		{
			return View();
		}

		[Obsolete]
		public async Task<IActionResult> AjaxFormEdit(int id)
		{
			var item = await UserDa.GetId(id);
			if (item == null) return BadRequest(msg);
			UserAdmins obj = new()
			{
				Id = item.Id,
				Name = item.Name,
				UserName = item.UserName,
			};

			UserAdminViewModel model = new()
			{
				Item = obj
			};
			return View(model);
		}

		[HttpPost]
		public async Task<IActionResult> ActionAdd()
		{
			UserAdmins obj = new();
			await TryUpdateModelAsync(obj);
			obj.PasswordSalt = Utility.CreateSaltKey(8);
			obj.Password = Utility.CreatePasswordHash(obj.Password!, obj.PasswordSalt);
			var rs = await BaseDa.Insert(obj, "UserAdmins");
			if (rs == 0)
			{
				msg.Message = "Thêm mới thất bại";
				return BadRequest(msg);
			}
			msg.Message = "Thêm mới thành công";
			msg.Errors = false;
			return Ok(msg);
		}
		[Obsolete]
		[HttpPost]
		public async Task<IActionResult> ActionEdit()
		{
			UserAdmins obj = new();
			await TryUpdateModelAsync(obj);
			var item = await UserDa.GetId(obj.Id);
			if (item == null) return BadRequest(msg);
			item.Name = obj.Name;
			var rs = await BaseDa.Update(item, "UserAdmins");
			if (rs == 0)
			{
				msg.Message = "Cập nhật thất bại";
				return BadRequest(msg);
			}
			msg.Message = "Cập nhật thành công";
			msg.Errors = false;
			return Ok(msg);
		}

		[HttpPost]
		public async Task<IActionResult> ActionDelete(int id)
		{
			var rs = await BaseDa.Delete(id, "UserAdmins");
			if (rs == 0)
			{
				msg.Message = "Xóa thất bại";
				return BadRequest(msg);
			}
			msg.Message = "Xóa thành công";
			msg.Errors = false;
			return Ok(msg);
		}

	}
}
